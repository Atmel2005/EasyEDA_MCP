"use strict";
var edaEsbuildExportName = (() => {
    var __defProp = Object.defineProperty;
    var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
    var __getOwnPropNames = Object.getOwnPropertyNames;
    var __hasOwnProp = Object.prototype.hasOwnProperty;
    var __export = (target, all) => {
        for (var name in all)
            __defProp(target, name, { get: all[name], enumerable: true });
    };
    var __copyProps = (to, from, except, desc) => {
        if (from && typeof from === "object" || typeof from === "function")
            for (let key of __getOwnPropNames(from))
                if (!__hasOwnProp.call(to, key) && key !== except)
                    __defProp(to, key, {
                        get: () => from[key],
                        enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
                    });
        return to;
    };
    var __toCommonJS = (mod) =>
        __copyProps(__defProp({}, "__esModule", { value: true }), mod);

    var exports_all = {};
    __export(exports_all, {
        activate: () => activate,
        deactivate: () => deactivate,
        about: () => about
    });

    var WS_ID = "atm-mcp-ws";
    var WS_URL = "ws://127.0.0.1:8787";
    var SCAN_INTERVAL = 5000;
    var CONNECT_TIMEOUT = 2000;
    var HEARTBEAT_INTERVAL = 10000;
    var HEARTBEAT_TIMEOUT = 3000;

    var state = eda.__atmMcpState ??= {
        isRegistered: false,
        isConnecting: false,
        isScanEnabled: false,
        isStartupInitialized: false,
        apiCatalog: null
    };

    function loadApiCatalog() {
        if (state.apiCatalog) return;
        try {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", eda.sys_Environment.getExtensionPath("atm-mcp") + "/api_commands.json", false);
            xhr.send();
            if (xhr.status === 200 || xhr.status === 0) {
                state.apiCatalog = JSON.parse(xhr.responseText);
                eda.sys_Log.add("ATM_MCP: API catalog loaded (" + Object.keys(state.apiCatalog.categories || {}).length + " categories)", ESYS_LogType.INFO);
            }
        } catch (e) {
            eda.sys_Log.add("ATM_MCP: Failed to load api_commands.json: " + e.message, ESYS_LogType.WARNING);
        }
    }

    function sendToServer(event, body) {
        eda.sys_WebSocket.send(WS_ID, JSON.stringify({
            event: event,
            body: JSON.stringify(body)
        }));
    }

    function clearHeartbeatTimeout() {
        if (state.heartbeatTimeout) {
            clearTimeout(state.heartbeatTimeout);
            state.heartbeatTimeout = void 0;
        }
    }

    function stopHeartbeat() {
        if (state.heartbeatTimer) {
            clearInterval(state.heartbeatTimer);
            state.heartbeatTimer = void 0;
        }
        clearHeartbeatTimeout();
    }

    function onDisconnect(reason) {
        if (!state.isRegistered && !state.isConnecting) return;
        state.isRegistered = false;
        state.isConnecting = false;
        clearConnectTimeout();
        stopHeartbeat();
        closeSocket(reason);
        eda.sys_Log.add("ATM_MCP disconnected: " + reason, ESYS_LogType.WARNING);
    }

    function sendHeartbeat() {
        if (!state.isRegistered) return;
        clearHeartbeatTimeout();
        try {
            sendToServer("ping", { ts: Date.now() });
        } catch (e) {
            onDisconnect("heartbeat send failed: " + e.message);
            return;
        }
        state.heartbeatTimeout = setTimeout(() => {
            onDisconnect("heartbeat timeout");
        }, HEARTBEAT_TIMEOUT);
    }

    function startHeartbeat() {
        stopHeartbeat();
        sendHeartbeat();
        state.heartbeatTimer = setInterval(sendHeartbeat, HEARTBEAT_INTERVAL);
    }

    async function handleMessage(msg) {
        if (msg.event === "connected") {
            eda.sys_Log.add("ATM_MCP WebSocket connected", ESYS_LogType.INFO);
            return;
        }
        if (msg.event === "pong") {
            clearHeartbeatTimeout();
            return;
        }

        var body = msg.body ? JSON.parse(msg.body) : {};
        var id = body.id;

        var respond = function (ok, result, error) {
            if (id) {
                sendToServer(msg.event + ":result", {
                    id: id,
                    ok: ok,
                    result: result,
                    error: error instanceof Error ? error.message : error ? String(error) : void 0
                });
            }
        };

        try {
            eda.sys_Log.add("ATM_MCP event: " + msg.event, ESYS_LogType.INFO);

            if (msg.event === "get-schematic") {
                var ids = await eda.sch_PrimitiveComponent.getAllPrimitiveId().catch(() => []);
                respond(true, { primitiveIds: [...ids] });
                return;
            }

            if (msg.event === "get-current-project-info") {
                var info = await eda.dmt_Project.getCurrentProjectInfo();
                if (!info) throw new Error("Current project info not found");
                respond(true, info);
                return;
            }

            if (msg.event === "open-document") {
                var uuid = body.documentUuid;
                if (!uuid) throw new Error("Missing documentUuid");
                var tabId = await eda.dmt_EditorControl.openDocument(uuid);
                respond(true, { tabId: tabId, documentUuid: uuid });
                return;
            }

            if (msg.event === "create-schematic") {
                var boardName = typeof body.boardName === "string" ? body.boardName : void 0;
                var pageUuid = await eda.dmt_Schematic.createSchematic(boardName);
                respond(true, { schematicFirstPageUuid: pageUuid });
                return;
            }

            if (msg.event === "create-schematic-page") {
                var schUuid = body.schematicUuid;
                if (!schUuid) throw new Error("Missing schematicUuid");
                var newPage = await eda.dmt_Schematic.createSchematicPage(schUuid);
                respond(true, { schematicUuid: schUuid, schematicPageUuid: newPage });
                return;
            }

            if (msg.event === "modify-schematic-name") {
                var sUuid = body.schematicUuid, sName = body.schematicName;
                if (!sUuid) throw new Error("Missing schematicUuid");
                if (!sName) throw new Error("Missing schematicName");
                var ok2 = await eda.dmt_Schematic.modifySchematicName(sUuid, sName);
                respond(true, { success: ok2 });
                return;
            }

            if (msg.event === "modify-schematic-page-name") {
                var pUuid = body.schematicPageUuid, pName = body.schematicPageName;
                if (!pUuid) throw new Error("Missing schematicPageUuid");
                if (!pName) throw new Error("Missing schematicPageName");
                var ok3 = await eda.dmt_Schematic.modifySchematicPageName(pUuid, pName);
                respond(true, { success: ok3 });
                return;
            }

            if (msg.event === "get-api-catalog") {
                respond(true, state.apiCatalog || {error: "API catalog not loaded"});
                return;
            }

            if (msg.event === "execute-js") {
                var script = body.script;
                if (!script) throw new Error("Missing script");
                var AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;
                var fn = new AsyncFunction("eda", script);
                var result = await fn(eda);
                respond(true, result);
                return;
            }

            throw new Error("Unknown event: " + msg.event);

        } catch (err) {
            eda.sys_Log.add("ATM_MCP event error: " + msg.event + ": " + err.message, ESYS_LogType.ERROR);
            respond(false, void 0, err);
        }
    }

    function clearConnectTimeout() {
        if (state.connectTimeout) {
            clearTimeout(state.connectTimeout);
            state.connectTimeout = void 0;
        }
    }

    function closeSocket(reason) {
        try {
            eda.sys_WebSocket.close(WS_ID, 1000, reason);
        } catch (e) {}
    }

    function tryConnect(showWarning) {
        if (state.isRegistered || state.isConnecting || !state.isScanEnabled) return;
        state.isConnecting = true;
        closeSocket("Reconnect by ATM_MCP");

        state.connectTimeout = setTimeout(() => {
            state.isConnecting = false;
            clearConnectTimeout();
            closeSocket("ATM_MCP connect timeout");
            if (showWarning) {
                eda.sys_Log.add("ATM_MCP: Fail connect WebSocket", ESYS_LogType.ERROR);
                eda.sys_Message.showToastMessage("ATM_MCP: MCP server not found", ESYS_ToastMessageType.WARNING);
            }
        }, CONNECT_TIMEOUT);

        eda.sys_WebSocket.register(WS_ID, WS_URL,
            async function (e) {
                try {
                    var data = typeof e.data === "string" ? e.data : String(e.data);
                    await handleMessage(JSON.parse(data));
                } catch (err) {
                    eda.sys_Log.add("ATM_MCP message error: " + err.message, ESYS_LogType.ERROR);
                }
            },
            function () {
                state.isRegistered = true;
                state.isConnecting = false;
                clearConnectTimeout();
                startHeartbeat();
                eda.sys_Log.add("ATM_MCP WebSocket opened: " + WS_URL, ESYS_LogType.INFO);
                eda.sys_Message.showToastMessage("ATM_MCP connected", ESYS_ToastMessageType.SUCCESS);
            }
        );
    }

    function startScan(showWarning) {
        if (state.isScanEnabled) {
            tryConnect(showWarning);
            return;
        }
        state.isScanEnabled = true;
        tryConnect(showWarning);
        state.scanTimer = setInterval(() => tryConnect(false), SCAN_INTERVAL);
        eda.sys_Log.add("ATM_MCP scan started", ESYS_LogType.INFO);
    }

    function initOnStartup() {
        if (!state.isStartupInitialized) {
            state.isStartupInitialized = true;
            loadApiCatalog();
            startScan(false);
            return;
        }
        startScan(false);
    }

    initOnStartup();

    function activate(n, e) {
        initOnStartup();
    }

    async function about() {
        eda.sys_Dialog.showInformationMessage(
            "ATM_MCP Extension\n" +
            "Version 1.0.0\n" +
            "\n" +
            "Developed by Atmel Metall\n" +
            "https://atmel2005.github.io"
        );
    }

    function deactivate() {
        state.isScanEnabled = false;
        state.isConnecting = false;
        clearConnectTimeout();
        stopHeartbeat();
        if (state.scanTimer) {
            clearInterval(state.scanTimer);
            state.scanTimer = void 0;
        }
        closeSocket("ATM_MCP deactivated");
        state.isRegistered = false;
        eda.sys_Log.add("ATM_MCP deactivated", ESYS_LogType.INFO);
    }

    return __toCommonJS(exports_all);
})();