# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - 2026-07-01
### Added
- Initial release of the ATM_MCP extension for EasyEDA Pro.
- Full WebSocket integration for remote AI control.
- Support for schematic primitives and PCB component placement manipulation.
- Dynamically loaded API command catalog for LLM assistants.
